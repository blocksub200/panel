# HACK-GALLERY
آموزش هک گالری با ارسال اسکریپت به قربانی در ترموکس - hack gallery in termux


<a href="https://telegra.ph/%D8%A2%D9%85%D9%88%D8%B2%D8%B4-%D9%87%DA%A9-%DA%AF%D8%A7%D9%84%D8%B1%DB%8C-%D8%A7%D9%81%D8%B1%D8%A7%D8%AF%E2%80%8C-%D8%A8%D8%A7-%D8%A7%D8%B3%D8%AA%D9%81%D8%A7%D8%AF%D9%87-%D8%A7%D8%B2-%D8%AA%D8%B1%D9%85%D9%88%DA%A9%D8%B3-04-06">آموزش استفاده از اسکریپت</a>

